
import React from 'react';
import { motion } from 'framer-motion';
import { Check, X } from 'lucide-react';

const ComparisonTable = () => {
  const features = [
    { name: "REPUTATION SYSTEM", fated: true, linkedin: false, trad: false, freelance: true },
    { name: "ANONYMITY", fated: true, linkedin: false, trad: false, freelance: false },
    { name: "AI MATCHING", fated: true, linkedin: false, trad: false, freelance: false },
    { name: "TASK-BASED WORK", fated: true, linkedin: false, trad: false, freelance: true },
    { name: "XP DECAY", fated: true, linkedin: false, trad: false, freelance: false },
    { name: "COMMUNITY", fated: true, linkedin: true, trad: false, freelance: false },
    { name: "PRICING", fated: "FAIR", linkedin: "PREMIUM", trad: "HIGH", freelance: "HIGH" },
  ];

  return (
    <section className="py-20 px-6 relative">
      <div className="max-w-[1200px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-16 neon-text-purple"
        >
          SYSTEM COMPARISON
        </motion.h2>
        
        <div className="overflow-x-auto pb-6 glass-panel p-4">
          <table className="w-full min-w-[800px] border-collapse">
            <thead>
              <tr>
                <th className="p-4 text-left text-gray-500 font-bold border-b border-gray-800 tracking-widest text-xs">FEATURE</th>
                <th className="p-4 text-center text-cyan-400 font-bold text-lg border-b border-cyan-500/50 bg-cyan-900/10 tracking-widest neon-text-cyan">FATED</th>
                <th className="p-4 text-center text-gray-400 font-bold border-b border-gray-800 tracking-widest text-xs">LINKEDIN</th>
                <th className="p-4 text-center text-gray-400 font-bold border-b border-gray-800 tracking-widest text-xs">TRADITIONAL</th>
                <th className="p-4 text-center text-gray-400 font-bold border-b border-gray-800 tracking-widest text-xs">FREELANCE</th>
              </tr>
            </thead>
            <tbody>
              {features.map((feature, index) => (
                <motion.tr 
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="hover:bg-white/5 transition-colors"
                >
                  <td className="p-4 text-white font-bold text-xs border-b border-gray-800">{feature.name}</td>
                  
                  {/* FatedFortress Column */}
                  <td className="p-4 text-center border-b border-gray-800 bg-cyan-900/5 border-l border-r border-cyan-500/20">
                    {feature.fated === true ? (
                      <div className="flex justify-center"><Check className="w-5 h-5 text-cyan-400" /></div>
                    ) : feature.fated === false ? (
                      <div className="flex justify-center"><X className="w-5 h-5 text-red-500" /></div>
                    ) : (
                      <span className="text-cyan-400 font-bold text-xs">{feature.fated}</span>
                    )}
                  </td>
                  
                  {/* Other Columns */}
                  <td className="p-4 text-center border-b border-gray-800">
                    {feature.linkedin === true ? <div className="flex justify-center"><Check className="w-4 h-4 text-gray-600" /></div> : feature.linkedin === false ? <div className="flex justify-center"><X className="w-4 h-4 text-gray-700" /></div> : <span className="text-gray-600 text-xs">{feature.linkedin}</span>}
                  </td>
                  <td className="p-4 text-center border-b border-gray-800">
                    {feature.trad === true ? <div className="flex justify-center"><Check className="w-4 h-4 text-gray-600" /></div> : feature.trad === false ? <div className="flex justify-center"><X className="w-4 h-4 text-gray-700" /></div> : <span className="text-gray-600 text-xs">{feature.trad}</span>}
                  </td>
                  <td className="p-4 text-center border-b border-gray-800">
                    {feature.freelance === true ? <div className="flex justify-center"><Check className="w-4 h-4 text-gray-600" /></div> : feature.freelance === false ? <div className="flex justify-center"><X className="w-4 h-4 text-gray-700" /></div> : <span className="text-gray-600 text-xs">{feature.freelance}</span>}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default ComparisonTable;
