
import React from 'react';
import { motion } from 'framer-motion';
import { Compass, Rocket, RefreshCw, GitBranch, ArrowRight } from 'lucide-react';

const UseCasesSection = () => {
  const useCases = [
    {
      icon: Compass,
      title: "SENIOR ENGINEER",
      description: "Test drive new tech stacks or leadership roles without leaving your day job. Build anonymously."
    },
    {
      icon: Rocket,
      title: "STARTUP FOUNDER",
      description: "Find co-founders who actually ship. Validate your MVP with a team of builders."
    },
    {
      icon: RefreshCw,
      title: "CAREER SWITCHER",
      description: "Break the 'no experience' loop. Earn verified XP on real projects."
    },
    {
      icon: GitBranch,
      title: "OPEN SOURCE",
      description: "Scale your project with committed contributors. Reward meaningful PRs."
    }
  ];

  return (
    <section className="py-20 px-6 relative">
      <div className="max-w-[1200px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-16 neon-text-purple"
        >
          OPERATIONAL ROLES
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {useCases.map((useCase, index) => {
            const Icon = useCase.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="group p-8 glass-panel hover:bg-purple-900/20 transition-all duration-300 hover:shadow-neon-purple"
              >
                <div className="w-12 h-12 rounded-none border border-purple-500 flex items-center justify-center mb-6 group-hover:bg-purple-500/20 transition-colors duration-300">
                  <Icon className="w-6 h-6 text-purple-400" />
                </div>
                
                <h3 className="text-lg font-bold mb-3 text-white tracking-widest">
                  {useCase.title}
                </h3>
                
                <p className="text-gray-400 mb-6 text-xs leading-relaxed">
                  {useCase.description}
                </p>
                
                <a href="#" className="inline-flex items-center text-purple-400 font-bold text-xs hover:text-purple-300 transition-colors tracking-widest">
                  INITIATE <ArrowRight className="w-3 h-3 ml-1" />
                </a>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default UseCasesSection;
