
import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

const EarlyAccessSection = () => {
  const tiers = [
    {
      name: 'PIONEER',
      price: '$99',
      benefits: [
        'LIFETIME 20% DISCOUNT',
        'FOUNDING MEMBER BADGE',
        'DIRECT INPUT ON FEATURES',
        'PRIORITY SUPPORT'
      ]
    },
    {
      name: 'CHAMPION',
      price: '$299',
      benefits: [
        'ALL PIONEER BENEFITS',
        '1-HOUR CONSULTING CALL',
        'EARLY API ACCESS',
        'PRIVATE DISCORD CHANNEL'
      ]
    },
    {
      name: 'FOUNDER',
      price: '$999',
      benefits: [
        'ALL CHAMPION BENEFITS',
        'ADVISORY BOARD SEAT',
        'CUSTOM INTEGRATION',
        'LIFETIME ACCESS'
      ]
    }
  ];

  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-5xl font-black text-center mb-6 neon-text-cyan"
        >
          ACCESS TIERS
        </motion.h2>
        
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-xl text-center mb-16 text-gray-400 tracking-widest"
        >
          SECURE FOUNDING STATUS BEFORE LAUNCH.
        </motion.p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers.map((tier, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="p-8 glass-panel relative overflow-hidden hover:shadow-neon-cyan transform hover:scale-105 transition-all duration-300"
            >
              <div className="relative z-10">
                <h3 className="text-2xl font-bold mb-2 text-white tracking-widest">
                  {tier.name}
                </h3>
                <p className="text-4xl font-black mb-8 text-cyan-400 neon-text-cyan">
                  {tier.price}
                </p>
                
                <ul className="space-y-4">
                  {tier.benefits.map((benefit, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <Check className="w-5 h-5 flex-shrink-0 mt-0.5 text-cyan-400" />
                      <span className="text-sm text-gray-300">
                        {benefit}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EarlyAccessSection;
