
import React from 'react';
import { motion } from 'framer-motion';
import { UserPlus, Users, Rocket } from 'lucide-react';

const HowItWorksSection = () => {
  const steps = [
    {
      icon: UserPlus,
      title: 'CREATE PROFILE',
      description: 'Build your XP through verified contribution. No résumé required.'
    },
    {
      icon: Users,
      title: 'JOIN SQUAD',
      description: 'AI matches you with collaborators, or build your own team.'
    },
    {
      icon: Rocket,
      title: 'SHIP TOGETHER',
      description: 'Complete tasks, earn XP, build reputation. Together.'
    }
  ];

  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-20 neon-text-purple"
        >
          HOW IT WORKS
        </motion.h2>
        
        <div className="relative">
          {/* Connecting line - desktop */}
          <div className="hidden md:block absolute top-16 left-0 right-0 h-0.5 mx-32 bg-gradient-to-r from-cyan-500/20 via-purple-500/50 to-cyan-500/20" />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 relative">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="flex flex-col items-center text-center relative group"
                >
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center mb-8 relative z-10 bg-black border border-cyan-500 shadow-neon-cyan group-hover:scale-110 transition-transform duration-300"
                  >
                    <Icon className="w-8 h-8 text-cyan-400" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-white tracking-widest">
                    {step.title}
                  </h3>
                  <p className="text-lg text-gray-400 max-w-xs">
                    {step.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
