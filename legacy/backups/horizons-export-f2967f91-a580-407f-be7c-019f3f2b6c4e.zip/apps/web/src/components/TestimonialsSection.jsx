
import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const TestimonialsSection = () => {
  const testimonials = [
    {
      quote: "I STOPPED APPLYING TO JOBS. MY XP ON FATEDFORTRESS GOT ME A CONTRACT WITH A YC STARTUP IN 3 DAYS.",
      name: "SARAH CHEN",
      title: "SENIOR RUST ENGINEER",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
      rating: 5
    },
    {
      quote: "FINALLY, A PLACE WHERE MY CODE SPEAKS LOUDER THAN MY LACK OF A CS DEGREE. THE TEAM MATCHING IS UNCANNY.",
      name: "MARCUS RODRIGUEZ",
      title: "FULL STACK DEVELOPER",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
      rating: 5
    },
    {
      quote: "THE ANONYMITY FEATURE LET ME MOONLIGHT ON A CRYPTO PROJECT WITHOUT ALERTING MY EMPLOYER. GAME CHANGER.",
      name: "ALEX K.",
      title: "BLOCKCHAIN ARCHITECT",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
      rating: 5
    },
    {
      quote: "BUILT A DISTRIBUTED CACHE SYSTEM WITH TWO STRANGERS. WE'VE NOW FOUNDED A COMPANY TOGETHER.",
      name: "DAVID KIM",
      title: "SYSTEMS ENGINEER",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
      rating: 5
    }
  ];

  return (
    <section className="py-20 px-6 relative">
      <div className="max-w-[1200px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-16 neon-text-cyan"
        >
          BUILDER TRANSMISSIONS
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass-panel p-6 rounded-none border border-cyan-500/20 hover:border-cyan-400 hover:shadow-neon-cyan transition-all duration-300 group"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-3 h-3 fill-cyan-400 text-cyan-400" />
                ))}
              </div>
              
              <p className="text-gray-300 mb-6 text-xs leading-relaxed tracking-wide">
                "{testimonial.quote}"
              </p>
              
              <div className="flex items-center gap-3 mt-auto border-t border-gray-800 pt-4">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.name} 
                  className="w-8 h-8 rounded-full object-cover border border-cyan-500 grayscale group-hover:grayscale-0 transition-all"
                />
                <div>
                  <h4 className="font-bold text-white text-xs">{testimonial.name}</h4>
                  <p className="text-[10px] text-cyan-400">{testimonial.title}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
