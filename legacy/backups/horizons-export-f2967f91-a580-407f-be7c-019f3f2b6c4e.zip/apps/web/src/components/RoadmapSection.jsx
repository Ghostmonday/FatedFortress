
import React from 'react';
import { motion } from 'framer-motion';

const RoadmapSection = () => {
  const quarters = [
    {
      period: "Q1 2026",
      title: "FOUNDATION",
      items: ["PLATFORM LAUNCH", "ANONYMOUS PROFILES", "AI MATCHING"]
    },
    {
      period: "Q2 2026",
      title: "EXPANSION",
      items: ["MOBILE APP", "ADVANCED ANALYTICS", "API ACCESS"]
    },
    {
      period: "Q3 2026",
      title: "ENTERPRISE",
      items: ["ENTERPRISE FEATURES", "CUSTOM INTEGRATIONS", "TEAM DASHBOARDS"]
    },
    {
      period: "Q4 2026",
      title: "DECENTRALIZATION",
      items: ["GLOBAL EXPANSION", "GOVERNANCE TOKEN", "DAO FEATURES"]
    }
  ];

  return (
    <section className="py-20 px-6 relative">
      <div className="max-w-[1200px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-20 neon-text-purple"
        >
          TRAJECTORY 2026
        </motion.h2>
        
        <div className="relative">
          {/* Connecting Line (Desktop) */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-purple-900 -translate-y-1/2 z-0" />
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-6 relative z-10">
            {quarters.map((q, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="flex flex-col md:items-center md:text-center relative"
              >
                {/* Dot */}
                <div className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 w-4 h-4 bg-black border-2 border-purple-500 shadow-neon-purple z-20 hidden md:block" />
                
                {/* Content Card */}
                <div className="md:mt-12 md:pt-8 p-6 glass-panel border-purple-500/30 hover:border-purple-400 hover:shadow-neon-purple transition-all duration-300 w-full">
                  <span className="inline-block px-3 py-1 border border-purple-500/50 text-purple-400 text-[10px] font-bold mb-3">
                    {q.period}
                  </span>
                  <h3 className="text-lg font-bold text-white mb-4 tracking-widest">{q.title}</h3>
                  <ul className="space-y-2 text-left md:text-center">
                    {q.items.map((item, i) => (
                      <li key={i} className="text-gray-400 text-[10px]">
                        • {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default RoadmapSection;
