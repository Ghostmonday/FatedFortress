
import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Lock, Eye } from 'lucide-react';

const TrustSecuritySection = () => {
  const features = [
    {
      icon: Shield,
      title: "PRIVACY FIRST",
      description: "Your data is yours. We never sell your information. You control exactly what is visible."
    },
    {
      icon: Lock,
      title: "VERIFIED CONTRIBUTION",
      description: "Cryptographically signed contribution records ensure that your XP is immutable."
    },
    {
      icon: Eye,
      title: "TRANSPARENT REPUTATION",
      description: "Open algorithms determine XP calculation. No black boxes. Pure math."
    }
  ];

  return (
    <section className="py-20 px-6 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500 opacity-5 blur-[100px] rounded-full pointer-events-none" />

      <div className="max-w-[1200px] mx-auto relative z-10">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-16 neon-text-cyan"
        >
          SECURITY PROTOCOLS
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="flex flex-col items-center text-center p-8 glass-panel hover:scale-105 hover:shadow-neon-cyan transition-transform duration-300"
              >
                <div className="w-16 h-16 rounded-full border-2 border-cyan-400 flex items-center justify-center mb-6 shadow-neon-cyan bg-black">
                  <Icon className="w-8 h-8 text-cyan-400" />
                </div>
                
                <h3 className="text-xl font-bold mb-4 text-white tracking-widest">
                  {feature.title}
                </h3>
                
                <p className="text-gray-400 leading-relaxed text-sm">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default TrustSecuritySection;
