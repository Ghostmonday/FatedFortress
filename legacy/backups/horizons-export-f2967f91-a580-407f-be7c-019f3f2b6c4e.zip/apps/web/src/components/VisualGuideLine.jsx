
import React from 'react';
import { motion } from 'framer-motion';

const VisualGuideLine = ({ className }) => {
  return (
    <div className={`w-full h-24 flex justify-center items-center overflow-hidden ${className}`}>
      <motion.svg
        width="2"
        height="100%"
        viewBox="0 0 2 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        <motion.line
          x1="1"
          y1="0"
          x2="1"
          y2="100"
          stroke="url(#gradient-line)"
          strokeWidth="2"
          strokeDasharray="100"
          initial={{ strokeDashoffset: 100 }}
          whileInView={{ strokeDashoffset: 0 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        />
        <defs>
          <linearGradient id="gradient-line" x1="1" y1="0" x2="1" y2="100" gradientUnits="userSpaceOnUse">
            <stop stopColor="#00D4FF" stopOpacity="0" />
            <stop offset="0.5" stopColor="#00D4FF" />
            <stop offset="1" stopColor="#7C3AED" stopOpacity="0" />
          </linearGradient>
        </defs>
      </motion.svg>
      
      {/* Decorative Node */}
      <motion.div 
        className="absolute w-3 h-3 bg-cyan-500 rounded-full shadow-neon-cyan"
        initial={{ scale: 0, opacity: 0 }}
        whileInView={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      />
    </div>
  );
};

export default VisualGuideLine;
