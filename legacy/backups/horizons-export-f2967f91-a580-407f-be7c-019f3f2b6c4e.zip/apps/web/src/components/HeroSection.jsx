
import React from 'react';
import { motion } from 'framer-motion';

const HeroSection = () => {
  return (
    <section 
      className="min-h-screen relative flex items-center justify-center bg-cover bg-center overflow-hidden"
      style={{ backgroundImage: `url('https://images.unsplash.com/photo-1684431542208-77b3cd9187b2')` }}
    >
      {/* Holographic Overlay */}
      <div className="absolute inset-0 bg-black/60 z-0" />
      <div className="absolute inset-0 holographic-overlay z-0 opacity-30" />
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 z-0 mix-blend-overlay" />
      
      {/* Grid Overlay */}
      <div className="absolute inset-0 z-0" 
           style={{ 
             backgroundImage: 'linear-gradient(rgba(0, 212, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 212, 255, 0.1) 1px, transparent 1px)',
             backgroundSize: '40px 40px',
             maskImage: 'radial-gradient(circle at center, black 40%, transparent 100%)'
           }} 
      />

      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
          className="border border-cyan-500/30 p-8 md:p-16 bg-black/40 backdrop-blur-sm rounded-lg shadow-neon-cyan relative group"
        >
          {/* Corner Accents */}
          <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-400" />
          <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-400" />
          <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-400" />
          <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-400" />

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl lg:text-8xl font-black mb-8 neon-text-cyan tracking-widest"
          >
            STOP BUILDING <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 drop-shadow-neon-purple">
              ALONE
            </span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl lg:text-2xl mb-12 max-w-3xl mx-auto text-gray-300 tracking-widest font-light"
          >
            BUILD WITH PEOPLE WHO ACTUALLY SHIP. NO RESUMES. NO LINKEDIN THEATER. JUST <span className="text-cyan-400 font-bold">EXECUTION</span>.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
          >
            <button 
              className="px-10 py-5 rounded-none font-bold text-lg text-black bg-cyan-400 hover:bg-cyan-300 hover:shadow-neon-cyan transition-all duration-300 tracking-widest clip-path-polygon"
              style={{ clipPath: 'polygon(10% 0, 100% 0, 100% 70%, 90% 100%, 0 100%, 0 30%)' }}
            >
              CREATE PROFILE
            </button>
            
            <button 
              className="px-10 py-5 rounded-none font-bold text-lg text-cyan-400 border border-cyan-400 hover:bg-cyan-400/10 hover:shadow-neon-cyan transition-all duration-300 tracking-widest"
              style={{ clipPath: 'polygon(10% 0, 100% 0, 100% 70%, 90% 100%, 0 100%, 0 30%)' }}
            >
              EARLY ACCESS
            </button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
