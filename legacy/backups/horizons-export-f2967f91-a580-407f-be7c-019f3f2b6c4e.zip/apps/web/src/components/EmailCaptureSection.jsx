
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Zap } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const EmailCaptureSection = () => {
  const [email, setEmail] = useState('');
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) {
      toast({
        title: "TRANSMISSION RECEIVED",
        description: "YOU HAVE BEEN ADDED TO THE WAITLIST.",
      });
      setEmail('');
    }
  };

  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-3xl mx-auto text-center">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-5xl font-black mb-6 neon-text-purple"
        >
          INITIATE LAUNCH SEQUENCE
        </motion.h2>
        
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-lg mb-8 text-gray-400 tracking-widest"
        >
          EARLY ACCESS MEMBERS GET FOUNDING PRIORITY AND LIFETIME BENEFITS.
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-4 py-2 border border-purple-500/50 bg-purple-900/20 mb-8"
        >
          <Zap className="w-4 h-4 text-purple-400" />
          <span className="text-purple-400 font-bold text-xs tracking-widest">LAUNCHING Q2 2026. SECURE YOUR SPOT.</span>
        </motion.div>
        
        <motion.form 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          onSubmit={handleSubmit}
          className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto"
        >
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ENTER YOUR EMAIL"
            required
            className="flex-1 px-6 py-4 bg-black border border-gray-700 text-white focus:border-purple-500 focus:shadow-neon-purple outline-none transition-all"
          />
          <button
            type="submit"
            className="px-8 py-4 font-bold text-lg text-white bg-purple-600 hover:bg-purple-500 hover:shadow-neon-purple transition-all duration-300 tracking-widest"
          >
            JOIN WAITLIST
          </button>
        </motion.form>
      </div>
    </section>
  );
};

export default EmailCaptureSection;
