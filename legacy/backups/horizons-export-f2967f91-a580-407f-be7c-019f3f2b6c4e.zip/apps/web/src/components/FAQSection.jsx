
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const FAQItem = ({ question, answer, isOpen, onClick }) => {
  return (
    <div 
      className="mb-4 border border-gray-800 hover:border-cyan-500/50 transition-colors bg-black/50"
    >
      <button
        onClick={onClick}
        className="w-full px-8 py-6 flex items-center justify-between text-left"
      >
        <span className={`text-lg font-bold tracking-widest transition-colors ${isOpen ? 'text-cyan-400 neon-text-cyan' : 'text-white'}`}>
          {question}
        </span>
        <ChevronDown 
          className={`w-6 h-6 transform transition-transform duration-300 text-cyan-400 ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="px-8 pb-6 pt-2 border-t border-gray-800">
              <p className="text-sm leading-relaxed text-gray-400">
                {answer}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      question: 'IS MY DATA PUBLIC?',
      answer: 'PRIVACY-FIRST. YOU CONTROL VISIBILITY. ANON MODE HIDES YOU FROM HUMANS—SYSTEM STILL TRACKS CONTRIBUTION.'
    },
    {
      question: 'HOW DOES XP WORK?',
      answer: 'EARN THROUGH VERIFIED TASK COMPLETION. DECAYS WITHOUT ACTIVITY. YOUR XP REFLECTS RECENT CONTRIBUTION.'
    },
    {
      question: 'CAN I JOIN ANONYMOUSLY?',
      answer: 'YES. ANON MODE LETS YOU PARTICIPATE WITHOUT EXPOSURE. TOGGLE ANYTIME.'
    },
    {
      question: 'WHAT IF I\'M NEW?',
      answer: 'BUILD CONFIDENCE THROUGH PROTECTED PARTICIPATION. NO RÉSUMÉ REQUIRED. JUST CONTRIBUTION.'
    },
    {
      question: 'HOW IS XP DECAY CALCULATED?',
      answer: 'XP DECAYS 5% MONTHLY WITHOUT CONTRIBUTION. THIS ENSURES THAT REPUTATION REFLECTS CURRENT CAPABILITY, NOT PAST GLORY.'
    },
    {
      question: 'CAN I EXPORT MY REPUTATION?',
      answer: 'YES. YOUR XP AND CONTRIBUTION HISTORY ARE PORTABLE. YOU CAN EXPORT A CRYPTOGRAPHICALLY SIGNED PROOF OF YOUR WORK HISTORY AT ANY TIME.'
    },
    {
      question: 'WHAT ABOUT DISPUTES?',
      answer: 'WE USE AN AI-MEDIATED RESOLUTION PROCESS FIRST. IF THAT FAILS, A TRANSPARENT APPEALS PROCESS INVOLVING HIGH-REPUTATION COMMUNITY MEMBERS IS TRIGGERED.'
    },
    {
      question: 'HOW DO YOU PREVENT GAMING THE SYSTEM?',
      answer: 'WE USE MULTI-SIGNAL VERIFICATION, PEER REVIEW, AND ANOMALY DETECTION ALGORITHMS TO IDENTIFY AND FLAG SUSPICIOUS PATTERNS IN CONTRIBUTION HISTORY.'
    }
  ];

  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-[1200px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-5xl font-black text-center mb-16 neon-text-cyan"
        >
          KNOWLEDGE BASE
        </motion.h2>
        
        <div className="max-w-4xl mx-auto">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
            >
              <FAQItem
                question={faq.question}
                answer={faq.answer}
                isOpen={openIndex === index}
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
