
import React from 'react';
import { motion } from 'framer-motion';

const SchismSection = () => {
  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/10 to-purple-900/10" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-16 text-white drop-shadow-neon-purple"
        >
          KNOW YOUR ALLIES
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-panel p-12 border border-purple-500/30 hover:shadow-neon-purple transition-all duration-500"
          >
            <h3 className="text-3xl font-bold mb-6 text-purple-400 neon-text-purple">
              FOR VETERANS
            </h3>
            <p className="text-lg text-gray-300">
              SPENT 15 YEARS MASTERING RUST? SHIPPED SYSTEMS AT SCALE? YOUR EXPERTISE DESERVES RESPECT. CURATE TEAMS OF EQUALS WHO SHARE YOUR STANDARDS.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-panel p-12 border border-cyan-500/30 hover:shadow-neon-cyan transition-all duration-500"
          >
            <h3 className="text-3xl font-bold mb-6 text-cyan-400 neon-text-cyan">
              FOR EVERYONE
            </h3>
            <p className="text-lg text-gray-300">
              NEW TO THIS? WANT TO LEARN? FIND MENTORS, NOT GATEKEEPERS. BUILD THROUGH CONTRIBUTION, NOT CREDENTIALS.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SchismSection;
