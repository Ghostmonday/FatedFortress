
import React from 'react';
import { Github, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="py-12 px-6 border-t border-cyan-500/30 relative overflow-hidden bg-black">
      <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-wrap justify-center md:justify-start gap-6">
            <a 
              href="#about" 
              className="hover:text-cyan-400 hover:shadow-neon-cyan transition-all text-gray-500 text-xs tracking-widest"
            >
              ABOUT
            </a>
            <a 
              href="#privacy" 
              className="hover:text-cyan-400 hover:shadow-neon-cyan transition-all text-gray-500 text-xs tracking-widest"
            >
              PRIVACY POLICY
            </a>
            <a 
              href="#terms" 
              className="hover:text-cyan-400 hover:shadow-neon-cyan transition-all text-gray-500 text-xs tracking-widest"
            >
              TERMS OF SERVICE
            </a>
          </div>
          
          <div className="flex gap-4">
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="GitHub"
            >
              <Github className="w-5 h-5 text-gray-500 hover:text-cyan-400 transition-colors" />
            </a>
            <a 
              href="https://twitter.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="Twitter"
            >
              <Twitter className="w-5 h-5 text-gray-500 hover:text-cyan-400 transition-colors" />
            </a>
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <p className="text-gray-600 text-[10px] tracking-widest">
            © 2026 EXPNET. BUILT BY BUILDERS, FOR BUILDERS.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
