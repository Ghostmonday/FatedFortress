
import React from 'react';
import { Helmet } from 'react-helmet';
import ScrollToTop from '@/components/ScrollToTop.jsx';
import HeroSection from '@/components/HeroSection.jsx';
import NotebookLMSection from '@/components/NotebookLMSection.jsx';
import ProblemSection from '@/components/ProblemSection.jsx';
import HowItWorksSection from '@/components/HowItWorksSection.jsx';
import KeyFeaturesSection from '@/components/KeyFeaturesSection.jsx';
import SchismSection from '@/components/SchismSection.jsx';
import EarlyAccessSection from '@/components/EarlyAccessSection.jsx';
import TestimonialsSection from '@/components/TestimonialsSection.jsx';
import UseCasesSection from '@/components/UseCasesSection.jsx';
import ComparisonTable from '@/components/ComparisonTable.jsx';
import CommunityHighlightsSection from '@/components/CommunityHighlightsSection.jsx';
import TrustSecuritySection from '@/components/TrustSecuritySection.jsx';
import RoadmapSection from '@/components/RoadmapSection.jsx';
import EmailCaptureSection from '@/components/EmailCaptureSection.jsx';
import FAQSection from '@/components/FAQSection.jsx';
import FinalCTASection from '@/components/FinalCTASection.jsx';
import Footer from '@/components/Footer.jsx';
import VisualGuideLine from '@/components/VisualGuideLine.jsx';
import { Toaster } from '@/components/ui/toaster';

function App() {
  return (
    <>
      <Helmet>
        <title>FATEDFORTRESS - STOP BUILDING ALONE</title>
        <meta name="description" content="BUILD WITH PEOPLE WHO ACTUALLY SHIP. NO RESUMES. NO LINKEDIN THEATER. JUST EXECUTION. JOIN FATEDFORTRESS AND EARN XP THROUGH VERIFIED CONTRIBUTIONS." />
      </Helmet>
      
      <ScrollToTop />
      
      <div className="min-h-screen bg-black text-white overflow-x-hidden">
        <HeroSection />
        <VisualGuideLine />
        
        <NotebookLMSection />
        <VisualGuideLine />
        
        <ProblemSection />
        <VisualGuideLine />
        
        <HowItWorksSection />
        <VisualGuideLine />
        
        <KeyFeaturesSection />
        <VisualGuideLine />
        
        <SchismSection />
        <VisualGuideLine />
        
        <TestimonialsSection />
        <VisualGuideLine />
        
        <UseCasesSection />
        <VisualGuideLine />
        
        <CommunityHighlightsSection />
        <VisualGuideLine />
        
        <ComparisonTable />
        <VisualGuideLine />
        
        <TrustSecuritySection />
        <VisualGuideLine />
        
        <RoadmapSection />
        <VisualGuideLine />
        
        <EarlyAccessSection />
        <VisualGuideLine />
        
        <EmailCaptureSection />
        <VisualGuideLine />
        
        <FAQSection />
        <VisualGuideLine />
        
        <FinalCTASection />
        <Footer />
        <Toaster />
      </div>
    </>
  );
}

export default App;
