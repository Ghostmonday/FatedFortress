
import React from 'react';
import { motion } from 'framer-motion';

const ProblemSection = () => {
  const problems = [
    {
      title: "RESUMES LIE. EXECUTION DOESN'T.",
      description: "Self-reported skills mean nothing. Real contribution tells the truth."
    },
    {
      title: "BUILDING ALONE IS SLOW.",
      description: "Great ideas die in isolation. The right team accelerates everything."
    },
    {
      title: "IDENTITY THEATER IS EXHAUSTING.",
      description: "Why perform for recruiters when you can just build?"
    }
  ];

  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {problems.map((problem, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="glass-panel p-8 rounded-lg hover:shadow-neon-cyan transition-all duration-500 group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <h3 className="text-2xl font-bold mb-4 text-cyan-400 group-hover:text-white transition-colors neon-text-cyan">
                {problem.title}
              </h3>
              <p className="text-lg text-gray-400 group-hover:text-gray-200 transition-colors">
                {problem.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
