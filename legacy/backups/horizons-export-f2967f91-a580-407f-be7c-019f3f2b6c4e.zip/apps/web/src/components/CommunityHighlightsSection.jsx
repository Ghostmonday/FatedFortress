
import React from 'react';
import { motion } from 'framer-motion';
import { Users, Trophy } from 'lucide-react';

const CommunityHighlightsSection = () => {
  const projects = [
    {
      name: "DISTRIBUTED CACHE",
      description: "High-performance in-memory key-value store with eventual consistency.",
      teamSize: 3,
      xp: 12,
      stack: ["RUST", "GO"]
    },
    {
      name: "AI TRAINING PIPELINE",
      description: "Scalable infrastructure for distributed model training on consumer hardware.",
      teamSize: 5,
      xp: 28,
      stack: ["PYTHON", "CUDA"]
    },
    {
      name: "COLLAB TOOL",
      description: "Conflict-free replicated data type (CRDT) implementation for text editing.",
      teamSize: 4,
      xp: 18,
      stack: ["TS", "WS"]
    },
    {
      name: "BLOCKCHAIN INDEXER",
      description: "High-throughput EVM event indexer with GraphQL API.",
      teamSize: 2,
      xp: 15,
      stack: ["SOLIDITY", "RUST"]
    },
    {
      name: "GAME ENGINE",
      description: "Cross-platform 2D rendering engine with physics integration.",
      teamSize: 6,
      xp: 32,
      stack: ["C++", "UNREAL"]
    },
    {
      name: "DATA VISUALIZER",
      description: "Interactive dashboard builder for large-scale time-series data.",
      teamSize: 4,
      xp: 22,
      stack: ["REACT", "D3"]
    }
  ];

  return (
    <section className="py-20 px-6 relative">
      <div className="max-w-[1200px] mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-16 neon-text-cyan"
        >
          ACTIVE DEPLOYMENTS
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group p-6 glass-panel hover:border-cyan-400 hover:shadow-neon-cyan transition-all duration-300"
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors tracking-widest">
                  {project.name}
                </h3>
                <div className="flex items-center gap-1 bg-cyan-900/30 px-2 py-1 rounded border border-cyan-500/30 text-cyan-400 text-[10px] font-bold">
                  <Trophy className="w-3 h-3" />
                  {project.xp} XP
                </div>
              </div>
              
              <p className="text-gray-400 text-xs mb-6 h-12 line-clamp-2">
                {project.description}
              </p>
              
              <div className="flex items-center justify-between mt-auto">
                <div className="flex items-center gap-2 text-gray-500 text-[10px]">
                  <Users className="w-3 h-3" />
                  {project.teamSize} UNITS
                </div>
                
                <div className="flex gap-2">
                  {project.stack.map((tech, i) => (
                    <span key={i} className="px-2 py-1 bg-black border border-gray-700 text-gray-300 text-[10px]">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CommunityHighlightsSection;
