
import React from 'react';
import { motion } from 'framer-motion';

const KeyFeaturesSection = () => {
  const features = [
    {
      title: 'XP-BASED REPUTATION',
      description: 'Your work speaks. Earn experience points through verified contributions. No self-promotion required.'
    },
    {
      title: 'AI TEAM ASSEMBLY',
      description: 'Platform intelligence matches you with collaborators based on skills, timezone, and reliability.'
    },
    {
      title: 'ANONYMOUS PARTICIPATION',
      description: 'Senior engineers exploring? Newcomers building confidence? Contribute without exposure.'
    },
    {
      title: 'TRUST THAT MATTERS',
      description: 'Trust decays without signal. What you\'ve done recently matters more than what you did years ago.'
    },
    {
      title: 'TASK-BASED CONTRIBUTION',
      description: 'Clear scope. Verified completion. Earn XP for what you actually ship—not what you claim.'
    },
    {
      title: 'GEOGRAPHIC OPTIMIZATION',
      description: 'Match by timezone. Ship async. Find collaborators who work when you work.'
    }
  ];

  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-black text-center mb-16 neon-text-cyan"
        >
          SYSTEM FEATURES
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-panel p-8 rounded-none border-l-4 border-l-cyan-500 hover:bg-cyan-900/10 transition-all duration-300"
            >
              <h3 className="text-xl font-bold mb-4 text-cyan-400 tracking-widest">
                {feature.title}
              </h3>
              <p className="text-sm text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default KeyFeaturesSection;
