
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, FileText, X } from 'lucide-react';

const NotebookLMSection = () => {
  const [showTranscript, setShowTranscript] = useState(false);

  return (
    <section className="py-20 px-6 relative z-10">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass-panel rounded-xl p-1 overflow-hidden relative"
        >
          {/* Header */}
          <div className="bg-black/50 p-4 border-b border-cyan-500/30 flex justify-between items-center">
            <h2 className="text-xl md:text-2xl text-cyan-400 font-bold tracking-widest neon-text-cyan">
              UNDERSTAND FATEDFORTRESS IN 2 MINUTES
            </h2>
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/50" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
              <div className="w-3 h-3 rounded-full bg-green-500/50" />
            </div>
          </div>

          {/* Content Container */}
          <div className="p-6 md:p-10 flex flex-col md:flex-row gap-8 items-center">
            {/* Audio/Video Placeholder */}
            <div className="w-full md:w-2/3 aspect-video bg-black/80 rounded-lg border border-cyan-500/30 relative group overflow-hidden shadow-neon-cyan">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-20 rounded-full border-2 border-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform cursor-pointer bg-black/50 backdrop-blur-sm">
                  <Play className="w-8 h-8 text-cyan-400 ml-1 fill-cyan-400" />
                </div>
              </div>
              
              {/* Waveform Animation Placeholder */}
              <div className="absolute bottom-0 left-0 right-0 h-16 flex items-end justify-center gap-1 pb-4 opacity-50">
                {[...Array(20)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="w-1 bg-cyan-400"
                    animate={{ height: [10, 30, 15, 40, 10] }}
                    transition={{ duration: 1, repeat: Infinity, delay: i * 0.05 }}
                  />
                ))}
              </div>
              
              <div className="absolute top-4 left-4 text-xs text-cyan-400 font-mono border border-cyan-400/50 px-2 py-1 rounded">
                AI GENERATED BRIEFING
              </div>
            </div>

            {/* Info / Transcript Toggle */}
            <div className="w-full md:w-1/3 space-y-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <span className="text-cyan-400">00:00</span> What is FatedFortress?
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <span className="text-cyan-400">00:30</span> XP-Based Reputation
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <span className="text-cyan-400">01:00</span> Anonymous Participation
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <span className="text-cyan-400">01:30</span> The Builder's Advantage
                </div>
              </div>

              <button 
                onClick={() => setShowTranscript(!showTranscript)}
                className="w-full py-3 border border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 transition-colors rounded flex items-center justify-center gap-2 uppercase tracking-widest text-sm font-bold"
              >
                <FileText className="w-4 h-4" />
                {showTranscript ? 'Hide Transcript' : 'Read Transcript'}
              </button>
            </div>
          </div>

          {/* Transcript Overlay */}
          {showTranscript && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute inset-0 bg-black/95 z-20 p-8 overflow-y-auto"
            >
              <button 
                onClick={() => setShowTranscript(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
              <h3 className="text-cyan-400 mb-6 text-xl">TRANSCRIPT</h3>
              <p className="text-gray-300 font-mono text-sm leading-relaxed">
                [AI VOICE]: Welcome to FatedFortress. In a world where resumes are exaggerated and LinkedIn is a theater of vanity, we built a sanctuary for pure execution. FatedFortress is a reputation protocol based on verified XP. You don't say what you can do; you show it. By contributing to projects, you earn cryptographically verifiable experience points. Whether you're a senior engineer exploring new stacks anonymously or a founder looking for builders who actually ship, this is your fortress.
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </section>
  );
};

export default NotebookLMSection;
