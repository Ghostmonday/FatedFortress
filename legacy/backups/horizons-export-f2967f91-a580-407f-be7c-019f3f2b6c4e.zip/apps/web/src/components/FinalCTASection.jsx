
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const FinalCTASection = () => {
  return (
    <section className="py-24 px-6 relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-black to-purple-900/20 z-0" />
      
      <div className="max-w-[1200px] mx-auto relative z-10 text-center">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-5xl md:text-7xl font-black mb-6 text-white"
        >
          STOP WAITING. <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 drop-shadow-neon-purple">
            START BUILDING.
          </span>
        </motion.h2>
        
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-xl md:text-2xl text-gray-400 mb-12 max-w-2xl mx-auto tracking-widest"
        >
          JOIN 500+ BUILDERS ALREADY SHIPPING ON FATEDFORTRESS.
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8"
        >
          <button className="px-8 py-4 font-bold text-lg text-black bg-cyan-400 hover:bg-cyan-300 hover:shadow-neon-cyan transition-all duration-300 w-full sm:w-auto tracking-widest">
            CREATE PROFILE
          </button>
          
          <button className="px-8 py-4 font-bold text-lg text-cyan-400 border border-cyan-400 hover:bg-cyan-400/10 hover:shadow-neon-cyan transition-all duration-300 w-full sm:w-auto tracking-widest">
            JOIN WAITLIST
          </button>
          
          <button className="px-8 py-4 font-medium text-lg text-gray-400 hover:text-white transition-colors w-full sm:w-auto flex items-center justify-center gap-2 tracking-widest">
            READ DOCS <ArrowRight className="w-4 h-4" />
          </button>
        </motion.div>
        
        <motion.p 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="text-xs text-cyan-400 font-bold animate-pulse tracking-widest"
        >
          ⚡ FOUNDING MEMBERS GET LIFETIME BENEFITS. SPOTS LIMITED.
        </motion.p>
      </div>
    </section>
  );
};

export default FinalCTASection;
